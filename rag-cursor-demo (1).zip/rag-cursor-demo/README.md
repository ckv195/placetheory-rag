# RAG Cursor Demo (FastAPI + Chroma + SentenceTransformers)
Run locally or in Cursor. Backend in `/backend`, frontend in `/frontend`.
## Backend
```
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # optional: add OPENAI_API_KEY
python ingest.py
uvicorn app:app --reload --port 8000
```
## Frontend
```
cd frontend
python -m http.server 5500
# open http://localhost:5500
```
## Where the RAG lives
- Retrieval & generation: `/backend/rag.py`
- API endpoints: `/backend/app.py`
- Demo facts: `/backend/data/nuggets.csv`