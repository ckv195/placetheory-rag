const API_BASE = 'http://localhost:8000';
function addMessage(role, text){
  const box=document.getElementById('messages');
  const el=document.createElement('div'); el.className='message '+(role==='user'?'user':'assistant'); el.innerText=text;
  box.appendChild(el); box.scrollTop=box.scrollHeight;
}
async function sendQuestion(q){
  addMessage('user', q);
  try{
    const res = await fetch(`${API_BASE}/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q,top_k:4})});
    const data = await res.json();
    addMessage('assistant', data.answer || JSON.stringify(data));
  }catch(err){ addMessage('assistant','Error: '+err.message); }
}
document.getElementById('chat-form').addEventListener('submit',(e)=>{e.preventDefault(); const q=document.getElementById('question').value.trim(); if(q){sendQuestion(q); document.getElementById('question').value='';}});